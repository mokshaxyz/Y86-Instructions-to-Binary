#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int hltconvert() {
    return 0;
}

int nopconvert() {
    return 16;
}

void rrmovlconvert(const char *instruction) {
    char src[4], dest[4];
    int src_reg, dest_reg;

    if (sscanf(instruction, "RRMOVL %3s, %3s", src, dest) != 2) {
        fprintf(stderr, "Error: Invalid RRMOVL instruction - %s\n", instruction);
    }

    if (strcmp(src, "%eax") == 0) {
        src_reg = 0;
    } else if (strcmp(src, "%ecx") == 0) {
        src_reg = 1;
    } else if (strcmp(src, "%edx") == 0) {
        src_reg = 2;
    } else if (strcmp(src, "%ebx") == 0) {
        src_reg = 3;
    } else if (strcmp(src, "%esi") == 0) {
        src_reg = 4;
    } else if (strcmp(src, "%edi") == 0) {
        src_reg = 5;
    } else if (strcmp(src, "%esp") == 0) {
        src_reg = 6;
    } else if (strcmp(src, "%ebp") == 0) {
        src_reg = 7;
    }

    if (strcmp(dest, "%eax") == 0) {
        dest_reg = 0;
    } else if (strcmp(dest, "%ecx") == 0) {
        dest_reg = 1;
    } else if (strcmp(dest, "%edx") == 0) {
        dest_reg = 2;
    } else if (strcmp(dest, "%ebx") == 0) {
        dest_reg = 3;
    } else if (strcmp(dest, "%esi") == 0) {
        dest_reg = 4;
    } else if (strcmp(dest, "%edi") == 0) {
        dest_reg = 5;
    } else if (strcmp(dest, "%esp") == 0) {
        dest_reg = 6;
    } else if (strcmp(dest, "%ebp") == 0) {
        dest_reg = 7;
    }

    // Construct the binary representation
    int opcode = 0x20; // RRMOVL opcode
    int binary = (opcode << 4) | (src_reg << 20) | (dest_reg << 16);

    printf("%.8d\n", binary); // Print in decimal format
}

int main() {
    FILE *inputFile;
    int a, b;
    char instruction[50];

    inputFile = fopen("textfile.txt", "r");

    while (fscanf(inputFile, "%s", instruction) == 1) {
        if (strcmp(instruction, "HLT") == 0) {
            a = hltconvert();
            printf("%.8d\n", a);
        } else if (strcmp(instruction, "NOP") == 0) {
            b = nopconvert();
            printf("%.8d\n", b);
        } else {
            rrmovlconvert(instruction);
        }
    }

    fclose(inputFile);
}
